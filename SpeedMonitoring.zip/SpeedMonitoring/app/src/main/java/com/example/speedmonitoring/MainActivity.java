package com.example.speedmonitoring;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends Activity {
    private static final int PERMISSION_REQUEST_CODE = 1;
    private float tempo = 0;
    private Button btnStartStop;
    private TextView textViewDistance;
    private TextView textViewSpeed;
    private LocationManager locationManager;
    private boolean isTracking = false;
    private Location lastLocation;
    private float totalDistance;
    private float maxDistance;
    private float estTime;
    private float maxtime;
    private float gas;
    private long startTime;
    private EditText max_distance;
    private EditText max_time;
    private TextView textViewTimeElapsed;
    private TextView tv_distancerest;
    private TextView tv_timeest;
    private TextView tv_totalgas;
    private TextView tv_velrecon;
    private Recon recon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gas = 0;
        btnStartStop = findViewById(R.id.btn_start_stop);
        textViewDistance = findViewById(R.id.text_view_distance);
        textViewSpeed = findViewById(R.id.text_view_speed);
        textViewTimeElapsed = findViewById(R.id.text_view_timeelapsed);
        tv_distancerest = findViewById(R.id.text_view_distrest);
        tv_timeest = findViewById(R.id.text_view_timeestimated);
        tv_totalgas = findViewById(R.id.text_view_gas);
        tv_velrecon = findViewById(R.id.text_view_speedrecon);


        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSION_REQUEST_CODE);
        }
    }

    public void startStopTracking(View view) {


        if (!isTracking) {
            max_distance = findViewById(R.id.pt_maxdistance);
            max_time = findViewById(R.id.pt_maxtime);
            maxDistance = Float.valueOf(max_distance.getText().toString()) * 1000;
            maxtime = Float.valueOf(max_time.getText().toString()) * 60;
            //recon = new Recon(Float.valueOf(max_time.getText().toString()), tv_timeest, tv_velrecon, tv_distancerest);
            //recon.start();
            startTracking();

        } else {
            stopTracking();
            //recon.interrupt();
        }
    }

   /* protected void onDestroy() {
        super.onDestroy();
        if (recon != null) {
            recon.interrupt();
        }
    }*/

    private void startTracking() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            isTracking = true;
            btnStartStop.setText("Stop");

            totalDistance = 0;
            startTime = System.currentTimeMillis();
            lastLocation = null;

            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, locationListener);

        }
    }

    private void stopTracking() {
        isTracking = false;
        btnStartStop.setText("Start");

        locationManager.removeUpdates(locationListener);
        totalDistance = 0;
        maxDistance = 0;
        updateDistance(0);
        updateSpeed(0);
        updateCalcs(1);
        gas = 0;
    }

    private final LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            if (isTracking) {
                if (lastLocation != null) {
                    float distance = location.distanceTo(lastLocation);
                    totalDistance += distance;
                    updateDistance(totalDistance);
                    float speedinst = location.getSpeed();
                    speedinst = speedinst * 36/10;
                    if(speedinst < 40){
                        gas = gas + (distance/(1000 * 21));
                    } else if (speedinst < 70) {
                        gas = gas + (distance/(1000 * 15));
                    }
                    else{
                        gas = gas + (distance/(1000 * 10));
                    }
                }
                lastLocation = location;



                long currentTime = System.currentTimeMillis();
                long elapsedTime = currentTime - startTime;
                float speed = (totalDistance / elapsedTime) * 1000;
                updateSpeed(speed);
                updateCalcs(speed);
            }
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }
    };

    private void updateCalcs(float speed){
        float distancia = maxDistance - totalDistance;

        estTime = distancia / speed;
        if (speed > 0) {
            tempo = totalDistance / speed;

            if (tempo < 60) {
                textViewTimeElapsed.setText(String.format("Tempo de deslocamento: %.0f s", tempo));
            } else if (tempo < 3600) {
                tempo = tempo / 60;
                textViewTimeElapsed.setText(String.format("Tempo de deslocamento:%.0f min", tempo));
            } else {
                tempo = tempo / 3600;
                textViewTimeElapsed.setText(String.format("Tempo de deslocamento:%.0f h", tempo));
            }
        }
        if(estTime < maxtime)
        {
            tv_velrecon.setText("Velocidade recomendada: 40 km/h");
        }
        else{
            float newspeed = distancia / (maxtime - tempo);
            newspeed = newspeed * 36/10;
            if(newspeed < 40) newspeed = 40;
            tv_velrecon.setText(String.format("Velocidade recomendada: %.0f km/h", newspeed));
        }

        if(distancia < 1000){
            tv_distancerest.setText(String.format("Distância restante: %.2f metros",distancia));
       }
        else {
            distancia = distancia / 1000;
            tv_distancerest.setText(String.format("Distância restante: %.2f Km", distancia));
        }


        if(estTime < maxtime){

        }
        else{

        }
        if(estTime < 60 ) {
            tv_timeest.setText(String.format("Tempo estimado: %.0f segundos", estTime));
        }
        else if (estTime < 3600){
            estTime = estTime / 60;
            tv_timeest.setText(String.format("Tempo estimado: %.0f minutos",estTime));
        }
        else{
            estTime = estTime / 3600;
            tv_timeest.setText(String.format("Tempo estimado: %.0f horas",estTime));
        }

        if(gas > 0) {
            float consumo = totalDistance / gas;
            consumo = consumo / 1000;
            tv_totalgas.setText(String.format("Consumo de combustível: %.2f Km/L", consumo));
        }
    }

    @SuppressLint("DefaultLocale")
    private void updateDistance(float distance) {
        if(distance < 1000) {
            textViewDistance.setText(String.format("Distância percorrida: %.2f metros", distance));
        }
        else{
            distance = distance/1000;
            textViewDistance.setText(String.format("Distância percorrida: %.2f Km", distance));
        }

    }

    @SuppressLint("DefaultLocale")
    private void updateSpeed(float speed) {
        speed = speed * 36 / 10 ;
        textViewSpeed.setText(String.format("Velocidade média: %.2f km/h", speed));
    }

    private void updateOthers(String text, TextView obj){
        obj.setText(text);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permissão concedida pelo usuário
                btnStartStop.setEnabled(true);
            } else {
                // Permissão negada pelo usuário
                // Lide com isso de acordo com a sua necessidade
                btnStartStop.setEnabled(false);
            }
        }
    }
}
