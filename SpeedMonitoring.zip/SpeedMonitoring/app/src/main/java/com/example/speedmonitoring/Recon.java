package com.example.speedmonitoring;

import android.os.Handler;
import android.util.Log;
import android.widget.TextView;

public class Recon extends Thread {
    private long tempoDecorrido;
    private TextView resultadoTextView;
    private TextView temp;
    private TextView dist;
    private Handler handler;
    private float tempmax;
    private int nodes;
    private float Fv;

    public Recon(float tempomax,  TextView tempest, TextView resultadoTextView, TextView distrest) {
        tempmax = tempomax;
        tempoDecorrido = (long) (tempomax * 60 * 100);
        nodes = 10;
        this.resultadoTextView = resultadoTextView;
        temp = tempest;
        dist = distrest;
        this.handler = new Handler();
    }

    @Override
    public void run() {
        try {
            // Pausa a execução da thread pelo tempo decorrido especificado
            Thread.sleep(tempoDecorrido);
            if(nodes >= 1) {
                nodes--;
                float ideal = nodes * tempoDecorrido / 1000;
                float real = Float.valueOf(temp.getText().toString());
                Fv = Float.valueOf(dist.getText().toString())/ (2*ideal - real);
                Fv = Fv * 36/10;
                if(Fv < 40) Fv = 40;
            }

            // Atualizar o TextView na interface do usuário
            handler.post(new Runnable() {
                @Override
                public void run() {
                    resultadoTextView.setText(String.format("Velocidade recomendada: %.0f Km/h", Fv));
                }
            });
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
